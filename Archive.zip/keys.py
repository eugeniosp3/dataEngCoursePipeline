# Use this code snippet in your app.
# If you need more information about configurations
# or implementing the sample code, visit the AWS docs:
# https://aws.amazon.com/developer/language/python/

import boto3
from botocore.exceptions import ClientError
from config import accessKeys


access_key_id, secret_access_key = accessKeys()


def get_secret():

    secret_name = "accessKeys"
    region_name = "us-east-1"

    # Create a Secrets Manager client
    session = boto3.session.Session()
    client = session.client(
        service_name='secretsmanager',
        region_name=region_name,
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key
    )

    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        # For a list of exceptions thrown, see
        # https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetSecretValue.html
        raise e

    # Decrypts secret using the associated KMS key.
    secret = get_secret_value_response['SecretString']

    return secret
    # Your code goes here.


key_pair = get_secret()


splitKeys = key_pair.split(",")[0].split(":")

accessKey = splitKeys[0].replace("'", "").replace(
    '"', "").replace(" ", "").replace("{", "")

secretKey = splitKeys[1].replace("'", "").replace(
    '"', "").replace(" ", "").replace("}", "")
print(accessKey, secretKey)
